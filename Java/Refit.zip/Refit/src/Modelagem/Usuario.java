/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelagem;

import Controle.Conexao;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author dsm2
 */
public class Usuario {
    private int codigo;
    private String data1;
    private String resultado;
    private int peso;
    private int altura;


    Conexao con = new Conexao();
    
    public Usuario() {
        this(0,"","",0,0);
    }

    public Usuario(int codigo, String data1, String resultado, int peso, int altura) {
        this.codigo = codigo;
        this.data1 = data1;
        this.resultado = resultado;
        this.peso = peso;
        this.altura = altura;

    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getData1() {
        return data1;
    }

    public void setData1(String data1) {
        this.data1 = data1;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }


    public Conexao getCon() {
        return con;
    }

    public void setCon(Conexao con) {
        this.con = con;
    }

    
        public void cadastrarUsuario(){           
      String sql= "Insert into usuario(Data1,Resultado,Peso,Altura)values "+
                "('"+ this.getData1()+"','"+this.getResultado()+"','"+this.getPeso()+"','"+ this.getAltura()+"' )";
        con.executeSQL(sql);
        JOptionPane.showMessageDialog(null, "Registrado com sucesso");     
    }

        
     public ResultSet consultar(){
        ResultSet tabela;
        tabela = null;
        
        String sql= "Select * from usuario";
        tabela = con.RetornarResultset(sql);
     return tabela;   
    }



     public ResultSet consultarCampoEspecifico(){
        ResultSet tabela;
        tabela = null;
    
        try{
          String sql="Select * from Usuario where Resultado like '"+ getResultado()+"%'";
          tabela= con.RetornarResultset(sql);                  
       
           }
           catch(Exception sqle){
                JOptionPane.showMessageDialog(null,"Atenção..."+sqle.getMessage());
           }
        return tabela;    
    }
    
      public void excluir(){
        String sql;
        sql= "Delete from Usuario where codigo="+ getCodigo();
        con.executeSQL(sql);
        JOptionPane.showMessageDialog(null, "Registro excluido com sucesso...");
    }
    public void alterar(){
        String sql;
        sql="Update Usuario set Data1='"+ this.getData1()+"',Resultado='"+this.getResultado()+"',Peso='"+this.getPeso()+"',Altura='"+this.getAltura()+"'where codigo="+codigo;
        con.executeSQL(sql);
        JOptionPane.showMessageDialog(null, "Registro alterado com sucesso...");
        
    }
}
